/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestfirstsearch;
import java.util.*;
/**
 *
 * @author Akter
 */
public class BestFirstSearch {

   public static void main(String[] args) {
        // TODO code application logic here

        PriorityQueue <Node> q = new PriorityQueue<>((a,b) -> a.cost - b.cost);  
        int goal;
        
        int mat[][] = { 
                {0,3,5,1,0,0,0,0,0,0},
                {3,0,0,0,0,0,6,5,0,0},
                {5,0,0,0,0,0,0,0,0,0},
                {1,0,0,0,4,6,0,0,0,0},
                {0,0,0,4,0,0,0,0,2,1},
                {0,0,0,6,0,0,0,0,0,0},
                {0,6,0,0,0,0,0,0,0,0},
                {0,5,0,0,0,0,0,0,0,0},
                {0,0,0,0,2,0,0,0,0,0},
                {0,0,0,0,1,0,0,0,0,0},
                                   
        };
       
       
        System.out.print("Enter goal: ");
        Scanner scan=new Scanner (System.in);
        goal = scan.nextInt();

        int visited[] = new int[10];
        for (int i = 0; i<10; i++){
            visited[i] = 0;
        }
        
        q.add(new Node(0,mat[0][0]));
        
        while(!q.isEmpty()){
            int top = q.poll().id;
            visited[top] = 1;
            System.out.println(top);
            if(top == goal){
               System.out.println("Goal Found");
               return;
            }
            for (int i = 0; i<10; i++){
                if(mat[top][i] > 0 && visited[i] == 0){
                    q.add(new Node(i, mat[top][i]));
                }
            }
        }
    }
}




