import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.io.*;

public class First {
	JFrame f;

	First() {
		f = new JFrame();
		f.setSize(300, 250);
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel l1 = new JLabel("Name");
		JTextField lt1 = new JTextField();
		JLabel l2 = new JLabel("Id");
		JTextField lt2 = new JTextField();
		JLabel l3 = new JLabel("CGPA");
		JTextField lt3 = new JTextField();
		JLabel l4 = new JLabel("Trimester");
		JTextField lt4 = new JTextField();

		JButton b2 = new JButton("Submit");

		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String cust_Name = lt1.getText();
				String cust_Id = lt2.getText();
				String cust_CGP = lt3.getText();
			 String cust_trimester = lt4.getText();
				System.out.println(cust_Name);

				BufferedWriter writer = null;
				try {
					writer = new BufferedWriter(new FileWriter("info.txt", true));
					writer.write(cust_Name);
					writer.write(" ");
					writer.write(cust_Id);
					writer.write(" ");
					writer.write(cust_CGP);
					writer.write(" ");
					writer.write(cust_trimester);
					writer.newLine();
					writer.flush();
					

				} catch (IOException e) {
				} finally {
					try {
						if (writer != null)
							writer.close();
					} catch (IOException e) {
					}
				}

			}
		});

		l1.setBounds(10, 10, 50, 20);
		lt1.setBounds(80, 10, 100, 20);
		b2.setBounds(100, 150, 80, 20);
		l2.setBounds(10, 40, 50, 20);
		lt2.setBounds(80, 40, 100, 20);
		l3.setBounds(10, 70, 50, 20);
		lt3.setBounds(80, 70, 100, 20);
		l4.setBounds(10, 100, 50, 20);
		lt4.setBounds(80, 100, 100, 20);
		f.add(l1);
		f.add(b2);
		f.add(l2);
		f.add(lt1);
		f.add(lt2);
		f.add(lt3);
		f.add(lt4);
		f.add(l3);
		f.add(l4);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new First();
	}
}