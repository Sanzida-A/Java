import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Record {
	static String fn, fc;

	public static void main(String args[]) {

		JFrame f;

		f = new JFrame();
		f.setSize(300, 250);
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel l1 = new JLabel("Name");
		JTextField lt1 = new JTextField();
		JLabel l2 = new JLabel("Id");
		JTextField lt2 = new JTextField();
		JLabel l3 = new JLabel("CGPA");
		JTextField lt3 = new JTextField();

		JButton b= new JButton("Search");

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				final String cust_id = lt2.getText();

				try {

					BufferedReader br = new BufferedReader(new FileReader("info.txt"));
					String str;

					while ((str = br.readLine()) != null) {
						String name = "", id = "", cgpa = "";
						String[] part = str.split(" ");
						name = part[0];
						id = part[1];
						cgpa = part[2];

						if (cust_id.compareTo(id) == 0) {
							fn = name;
							fc = cgpa;
							System.out.println(fn);
							System.out.println(fc);
							lt1.setText(fn);
							lt3.setText(fc);
						}
					}
					
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		l1.setBounds(10, 10, 50, 20);
		lt1.setBounds(80, 10, 100, 20);
		b.setBounds(100, 150, 80, 20);
		l2.setBounds(10, 40, 50, 20);
		lt2.setBounds(80, 40, 100, 20);
		l3.setBounds(10, 70, 50, 20);
		lt3.setBounds(80, 70, 100, 20);
		f.add(l2);
		f.add(lt2);
		f.add(b);
		f.add(l1);
		f.add(lt1);
		f.add(l3);
		f.add(lt3);
		f.setVisible(true);

	}
}
